Thanks for downloading this theme!

Theme Name: Tempo
Theme URL: https://bootstrapmade.com/tempo-free-onepage-bootstrap-theme/
Author: BootstrapMade.com
Author URL: https://bootstrapmade.com